// Avisos opcionales a un canal de Telegram cuando aparece una oportunidad con valor.
// Requiere los secretos TELEGRAM_BOT_TOKEN y TELEGRAM_CHAT_ID; sin ellos no hace nada.
const fs = require('fs');
const https = require('https');
const { consenso, CLAVES } = require('./motor');

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const CHAT = process.env.TELEGRAM_CHAT_ID;
const leer = (f, def) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return def; } };
const datos = leer('datos-ligas.json', { ligas: {} });
const enviados = leer('avisados.json', { ids: [] });
const ahora = Date.now();

const enviar = (texto) => new Promise((res) => {
  const body = JSON.stringify({ chat_id: CHAT, text: texto, disable_web_page_preview: true });
  const rq = https.request({ hostname: 'api.telegram.org', path: `/bot${TOKEN}/sendMessage`, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } }, (r) => { r.resume(); r.on('end', () => res(r.statusCode === 200)); });
  rq.on('error', () => res(false));
  rq.write(body);
  rq.end();
});

(async () => {
  if (TOKEN && CHAT) {
    const ops = [];
    for (const [liga, arr] of Object.entries(datos.ligas || {})) {
      for (const p of arr || []) {
        const t = new Date(p.commence_time).getTime();
        if (!p.id || enviados.ids.includes(p.id) || t <= ahora || t > ahora + 12 * 3600e3) continue;
        const c = consenso(p);
        if (!c) continue;
        const k = CLAVES.reduce((a, b) => (c.mejor[b].cuota * c.justa[b] > c.mejor[a].cuota * c.justa[a] ? b : a));
        const ev = c.mejor[k].cuota * c.justa[k] - 1;
        if (ev >= 0.04 && c.justa[k] >= 0.3) ops.push({ p, liga, k, c, ev });
      }
    }
    ops.sort((a, b) => b.ev - a.ev);
    for (const { p, liga, k, c, ev } of ops.slice(0, 5)) {
      const nombre = k === 'local' ? p.home_team : k === 'visitante' ? p.away_team : 'Empate';
      const ok = await enviar(`⚡ Oportunidad con valor (${liga})\n${p.home_team} vs ${p.away_team}\nSelección: ${nombre}\nProbabilidad de consenso: ${(c.justa[k] * 100).toFixed(1)}%\nMejor cuota: ${c.mejor[k].cuota.toFixed(2)} (${c.mejor[k].casa})\nValor esperado estimado: +${(ev * 100).toFixed(1)}%\n\n+18 · Estimación estadística, no garantiza resultados. Juega con responsabilidad.`);
      if (ok) enviados.ids.push(p.id);
    }
  }
  enviados.ids = enviados.ids.slice(-2000);
  fs.writeFileSync('avisados.json', JSON.stringify(enviados));
})();
