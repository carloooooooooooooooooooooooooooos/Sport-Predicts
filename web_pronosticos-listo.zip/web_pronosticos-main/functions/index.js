// Suscripciones SportPredicts: Stripe Checkout + webhook que concede/retira el acceso premium.
// El acceso se guarda como "custom claims" del usuario de Firebase (premium, premiumHasta).
const { onCall, onRequest, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const admin = require('firebase-admin');
const Stripe = require('stripe');

admin.initializeApp();
const db = admin.firestore();

const STRIPE_KEY = defineSecret('STRIPE_SECRET_KEY');
const STRIPE_WH = defineSecret('STRIPE_WEBHOOK_SECRET');
// JSON: {"mensual":"price_xxx","trimestral":"price_yyy","anual":"price_zzz"}
const STRIPE_PRICES = defineSecret('STRIPE_PRICES');
const REGION = 'europe-west1';
const ORIGENES_VALIDOS = ['https://fredy7005.github.io']; // añade aquí tu dominio propio

exports.crearCheckout = onCall({ region: REGION, secrets: [STRIPE_KEY, STRIPE_PRICES] }, async (req) => {
  if (!req.auth) throw new HttpsError('unauthenticated', 'Inicia sesión.');
  const { plan, origen } = req.data || {};
  const precios = JSON.parse(STRIPE_PRICES.value());
  if (!precios[plan]) throw new HttpsError('invalid-argument', 'Plan no válido.');
  if (!ORIGENES_VALIDOS.some((o) => String(origen).startsWith(o))) throw new HttpsError('invalid-argument', 'Origen no permitido.');

  const stripe = new Stripe(STRIPE_KEY.value());
  const uid = req.auth.uid;
  const ref = db.collection('clientes').doc(uid);
  let { stripeId } = (await ref.get()).data() || {};
  if (!stripeId) {
    const c = await stripe.customers.create({ email: req.auth.token.email, metadata: { uid } });
    stripeId = c.id;
    await ref.set({ stripeId }, { merge: true });
  }
  const sesion = await stripe.checkout.sessions.create({
    mode: 'subscription',
    customer: stripeId,
    client_reference_id: uid,
    line_items: [{ price: precios[plan], quantity: 1 }],
    subscription_data: { metadata: { uid } },
    allow_promotion_codes: true,
    locale: 'es',
    success_url: `${origen}?ok=1`,
    cancel_url: origen,
  });
  return { url: sesion.url };
});

exports.crearPortal = onCall({ region: REGION, secrets: [STRIPE_KEY] }, async (req) => {
  if (!req.auth) throw new HttpsError('unauthenticated', 'Inicia sesión.');
  const { stripeId } = (await db.collection('clientes').doc(req.auth.uid).get()).data() || {};
  if (!stripeId) throw new HttpsError('failed-precondition', 'No tienes suscripción.');
  const stripe = new Stripe(STRIPE_KEY.value());
  const s = await stripe.billingPortal.sessions.create({ customer: stripeId, return_url: String(req.data.origen) });
  return { url: s.url };
});

async function aplicarSuscripcion(sub) {
  const uid = sub.metadata && sub.metadata.uid;
  if (!uid) return;
  const activa = ['active', 'trialing'].includes(sub.status);
  const fin = sub.current_period_end || (sub.items && sub.items.data[0] && sub.items.data[0].current_period_end) || 0;
  await admin.auth().setCustomUserClaims(uid, { premium: activa, premiumHasta: activa ? fin : 0 });
  await db.collection('clientes').doc(uid).set({ estado: sub.status, hasta: fin }, { merge: true });
}

exports.stripeWebhook = onRequest({ region: REGION, secrets: [STRIPE_KEY, STRIPE_WH] }, async (req, res) => {
  const stripe = new Stripe(STRIPE_KEY.value());
  let evento;
  try {
    evento = stripe.webhooks.constructEvent(req.rawBody, req.headers['stripe-signature'], STRIPE_WH.value());
  } catch (e) {
    return res.status(400).send('Firma no válida');
  }
  if (['customer.subscription.created', 'customer.subscription.updated', 'customer.subscription.deleted'].includes(evento.type)) {
    await aplicarSuscripcion(evento.data.object);
  }
  res.json({ ok: true });
});
