# SportPredicts

Web de análisis de cuotas de fútbol (probabilidades de consenso sin margen, valor esperado EV, más/menos goles, doble oportunidad, hándicap y comparador de casas) para 23 competiciones.

## Páginas
- `index`, `competiciones`, `partidos`, `partido`, `partidos-hora`, `calculadora`: análisis y herramientas.
- `analisis-gratis`: 3 análisis completos gratis al día (cambian a las 7:00).
- `top-cuotas` (Premium): oportunidades con valor ordenadas por EV.
- `historial`: predicciones guardadas antes del partido y medidas contra el resultado real.
- `planes`, `soporte`, `legal`.

## Cómo calcula
Probabilidad de consenso = media de las probabilidades sin margen de todas las casas del feed. EV = mejor cuota disponible × probabilidad de consenso − 1. Es análisis de cuotas, no un modelo predictivo propio: descríbelo así en tu marketing.

## Datos y automatización (`.github/workflows/actualizar_datos.yml`, cada 6 h)
1. Descarga cuotas de The Odds API a `datos-ligas.json` (secreto `ODDS_API_KEY1`). Si la API falla y no hay datos, el workflow falla y conserva el JSON anterior.
2. `historial.js` guarda cada predicción **antes** del inicio y, pasadas 3 h, consulta el resultado real (endpoint `scores`, solo de las ligas con partidos pendientes). Los commits con fecha del repositorio sirven de registro auditable.
3. `avisos.js` (opcional) envía oportunidades con valor a un canal de Telegram si defines los secretos `TELEGRAM_BOT_TOKEN` y `TELEGRAM_CHAT_ID`.

Coste de la API: 23 ligas × 3 mercados × 4 ejecuciones al día supera el plan gratuito de The Odds API. Calcula tu plan y comprueba que permite uso comercial.

## Escudos
`Logos Equipos/<Liga>/` tiene los de La Liga (ver `ESCUDOS_MANUALES` en `app.js`). Para el resto se genera un escudo con iniciales. Para añadir uno oficial: copia el PNG y añade una línea en `ESCUDOS_MANUALES` (nombre en minúsculas y sin tildes). Usa solo imágenes con licencia o permiso.

## Cuentas y suscripciones
- Firebase Authentication: activa los proveedores **Correo/contraseña** y **Google**, y añade tu dominio en «Dominios autorizados».
- Precios actuales en `planes.html`: mensual 6,99 €, trimestral 18,99 €, anual 59,99 € (editables).
- Stripe: crea un producto con 3 precios recurrentes y copia sus `price_...`.
- Firebase: plan Blaze, `firebase-tools`, y los secretos `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` y `STRIPE_PRICES` (`{"mensual":"price_..","trimestral":"price_..","anual":"price_.."}`) con `firebase functions:secrets:set`.
- `firebase deploy --only functions`, y en Stripe un webhook hacia `stripeWebhook` con los eventos `customer.subscription.created`, `.updated` y `.deleted`.
- En `functions/index.js` añade tu dominio a `ORIGENES_VALIDOS` si usas uno propio.

## Antes de publicar o vender
- Completa los campos `[COMPLETAR]` de `legal.html` y `soporte.html`, y revisa los textos con un asesor.
- Revisa las reglas de Firebase. El bloqueo premium de la web es solo visual; para protección real de datos premium, sírvelos desde una función del servidor.
- Mantén el repositorio privado si vendes el código y no copies marca, diseño ni textos de otras webs.
