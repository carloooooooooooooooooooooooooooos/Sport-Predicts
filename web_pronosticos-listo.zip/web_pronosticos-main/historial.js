// Guarda cada predicción ANTES del inicio del partido y, cuando termina, anota el resultado real.
// Se ejecuta en GitHub Actions; los commits con fecha sirven de registro auditable.
const fs = require('fs');
const https = require('https');
const { consenso, CLAVES } = require('./motor');

const KEY = process.env.API_KEY;
const LIGAS = {
  PD: 'soccer_spain_la_liga', SD: 'soccer_spain_segunda_division', PL: 'soccer_epl', CL: 'soccer_uefa_champs_league',
  SA: 'soccer_italy_serie_a', BL: 'soccer_germany_bundesliga', L1: 'soccer_france_ligue_one', EL: 'soccer_uefa_europa_league',
  ECL: 'soccer_uefa_europa_conference_league', ED: 'soccer_netherlands_eredivisie', PPL: 'soccer_portugal_primeira_liga',
  ELC: 'soccer_efl_champ', MLS: 'soccer_usa_mls', BR: 'soccer_brazil_campeonato', MX: 'soccer_mexico_ligamx',
  ARG: 'soccer_argentina_primera_division', BEL: 'soccer_belgium_first_div', TUR: 'soccer_turkey_super_league',
  COL: 'soccer_conmebol_copa_libertadores', URU: 'soccer_chile_campeonato', JPN: 'soccer_japan_j_league',
  KOR: 'soccer_korea_kleague1', AUS: 'soccer_australia_aleague'
};

const leer = (f, def) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return def; } };
const get = (path) => new Promise((res) => {
  https.get({ hostname: 'api.the-odds-api.com', path }, (r) => {
    let d = '';
    r.on('data', (c) => { d += c; });
    r.on('end', () => { try { res(r.statusCode === 200 ? JSON.parse(d) : null); } catch (e) { res(null); } });
  }).on('error', () => res(null));
});

const ahora = Date.now();
const datos = leer('datos-ligas.json', { ligas: {} });
const hist = leer('historial.json', { partidos: [] });
const ids = new Set(hist.partidos.map((p) => p.id));
const r4 = (x) => Math.round(x * 10000) / 10000;

for (const [liga, arr] of Object.entries(datos.ligas || {})) {
  for (const p of arr || []) {
    if (!p.id || ids.has(p.id)) continue;
    if (new Date(p.commence_time).getTime() <= ahora) continue; // solo se guarda antes del inicio
    const c = consenso(p);
    if (!c) continue;
    const pick = CLAVES.reduce((a, b) => (c.justa[b] > c.justa[a] ? b : a));
    hist.partidos.push({
      id: p.id, liga, local: p.home_team, visitante: p.away_team, inicio: p.commence_time,
      guardado: new Date().toISOString(),
      prob: { local: r4(c.justa.local), empate: r4(c.justa.empate), visitante: r4(c.justa.visitante) },
      pick, cuota: c.mejor[pick].cuota, casa: c.mejor[pick].casa, ev: r4(c.mejor[pick].cuota * c.justa[pick] - 1),
      resultado: null
    });
  }
}

(async () => {
  const pend = hist.partidos.filter((p) => !p.resultado && new Date(p.inicio).getTime() < ahora - 3 * 3600e3);
  const porLiga = {};
  pend.forEach((p) => { (porLiga[p.liga] = porLiga[p.liga] || []).push(p); });
  for (const [liga, lista] of Object.entries(porLiga)) {
    if (!KEY || !LIGAS[liga]) break;
    const sc = await get(`/v4/sports/${LIGAS[liga]}/scores/?apiKey=${KEY}&daysFrom=3`);
    if (sc) {
      for (const p of lista) {
        const e = sc.find((x) => x.id === p.id);
        if (e && e.completed && Array.isArray(e.scores)) {
          const gl = Number((e.scores.find((s) => s.name === p.local) || {}).score);
          const gv = Number((e.scores.find((s) => s.name === p.visitante) || {}).score);
          if (Number.isFinite(gl) && Number.isFinite(gv)) {
            const gan = gl > gv ? 'local' : gl < gv ? 'visitante' : 'empate';
            p.resultado = { marcador: gl + '-' + gv, ganador: gan, acierto: gan === p.pick };
          }
        }
      }
    }
    await new Promise((r) => setTimeout(r, 400));
  }
  for (const p of hist.partidos) {
    if (!p.resultado && new Date(p.inicio).getTime() < ahora - 4 * 86400e3) p.resultado = { marcador: null, ganador: null, acierto: null };
  }
  hist.actualizacion = new Date().toISOString();
  hist.partidos = hist.partidos.slice(-3000);
  fs.writeFileSync('historial.json', JSON.stringify(hist));
  console.log('historial.json: ' + hist.partidos.length + ' predicciones, ' + hist.partidos.filter((p) => p.resultado && p.resultado.acierto !== null).length + ' evaluadas');
})();
