// Misma lógica de consenso que app.js, para los scripts de GitHub Actions.
const CLAVES = ['local', 'empate', 'visitante'];
const media = (a) => a.reduce((s, x) => s + x, 0) / a.length;

function consenso(p) {
  const lista = [];
  for (const casa of p.bookmakers || []) {
    const m = (casa.markets || []).find((x) => x.key === 'h2h');
    if (!m || !Array.isArray(m.outcomes)) continue;
    const pr = (n) => (m.outcomes.find((o) => o.name === n) || {}).price;
    const q = { local: pr(p.home_team), empate: pr('Draw'), visitante: pr(p.away_team) };
    if (!CLAVES.every((k) => Number.isFinite(q[k]) && q[k] > 1)) continue;
    lista.push({ casa: casa.title || casa.key, q });
  }
  if (lista.length < 2) return null;
  const justa = {};
  const mejor = {};
  CLAVES.forEach((k) => {
    justa[k] = media(lista.map(({ q }) => (1 / q[k]) / CLAVES.reduce((a, c) => a + 1 / q[c], 0)));
    const top = lista.reduce((a, b) => (b.q[k] > a.q[k] ? b : a));
    mejor[k] = { cuota: top.q[k], casa: top.casa };
  });
  return { justa, mejor };
}

module.exports = { consenso, CLAVES };
